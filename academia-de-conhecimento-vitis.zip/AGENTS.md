<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules (VITIS)
- Every access rule lives in RLS and security-definer SQL functions (`has_role`, `can_manage_area`, `can_see_visibility`, `can_read_article`); UI hiding is cosmetic only.
- Editorial status changes go only through RPCs (`save_draft`, `submit_draft`, `approve_draft`, `return_draft`, `publish_draft`, `archive_article`, `restore_article`, `confirm_review`); articles have no direct insert policy so the workflow cannot be bypassed.
- Edits to a published article live in `article_drafts`; the published row changes only on publish, which also snapshots into `article_versions` (never deleted).
- Search goes through the `search_articles` RPC (Portuguese FTS + unaccent, weighted vector maintained by trigger); add new searchable fields to `articles_search_trigger`.
- Attachments use the private `attachments` bucket at `<article_id>/<file>`, read via signed URLs gated by `can_read_article`.
- Pages are client-rendered under `src/routes/_authenticated/` and wrap content in `AppShell`; shared UI lives in `src/components/vitis`, admin tabs in `src/components/admin`.
- Design tokens come from the attached Mosto design system (imported first in `src/styles.css`, `data-theme` on <html>, `data-brand="vissimo"` on <body>); VITIS semantic tokens in `src/styles.css` map onto Mosto tokens. Why: one Víssimo visual language, brand-switchable by tokens.
- The side menu is built from the `collections` table (plus fixed sections in AppShell); never hardcode per-system entries. Why: curators manage menu items in Admin → "Menu e coleções".
- Per-person progress/favorites live in `article_reads` / `article_favorites`, scoped to `auth.uid()` by RLS. Why: each person sees only their own reading.
- Cover images are storage paths in the `attachments` bucket stored in `cover_image`; readable via a storage policy tied to `can_read_article`. Why: covers follow article visibility.
- All brand-dependent colours derive from `--brand-primary` / `--brand-secondary` in `src/styles.css`; `src/lib/brand.ts` sets them at runtime from `app_settings` (public `get_brand` RPC) and picks AA text colours. Why: admins rebrand without code changes.
- Logos (brand and systems) are small data URLs stored in `app_settings.brand_logo` / `systems.logo_url`. Why: public buckets are blocked in this workspace and the sign-in screen needs the logo.
- Article "models" per content type (`src/lib/templates.ts`) only provide placeholders and empty slots, never saved text. Why: no invented instructions.
- Systems with published/archived articles cannot be deleted (DB trigger); deactivate instead.
- Cultivo trails reuse `collections` (status/level/audience) with ordered modules in `collection_items`; quiz answers are curator-only and readers use `get_quiz`/`submit_quiz`; certificates come only from `issue_certificate`. Why: scoring and completion cannot be forged from the browser.
- Team managers see org members' progress via `manages_user()` RLS; queries of own reads/favorites must always filter `user_id = me`. Why: managers can also read their team's rows.
- Support opens the configurable `support_portal_url` and logs to `support_requests` (status reserved for a future Jira server function). Why: phase 2 creates tickets server-side without UI changes.
