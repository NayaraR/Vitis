<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Estrela-guia

Equipes de loja e clientes agem com a instrução certa e vigente quando precisam dela.

## Métrica

Artigos publicados abertos por leitores a cada semana
